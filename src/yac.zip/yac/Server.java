package yac;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Server extends UnicastRemoteObject implements ServerRemote
{

	public static void main(String[] args) throws RemoteException, MalformedURLException
	{
		Naming.rebind("ChatServer", new Server());
	}

	private final Map<String, ClientRemote> nickname_clients = new HashMap<>();

	public Server() throws RemoteException
	{
		System.out.println("Server started");
	}

	@Override
	public Set<String> getClientNicknames()
	{
		return nickname_clients.keySet();
	}

	@Override
	public synchronized void registerClient(String nickname, ClientRemote c) throws RemoteException
	{
		System.out.println("accepting new client " + nickname);
		nickname_clients.put(nickname, c);
	}

	@Override
	public synchronized void broadcastMessage(String sender, String msg) throws RemoteException
	{
		for (String n : nickname_clients.keySet())
		{
			// if the client is not the one that sent the message
			if (!n.equals(sender))
			{
				// relay the message
				nickname_clients.get(n).receivedBroadcastedMessage(sender, msg);
			}
		}
	}
}
