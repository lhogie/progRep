package yac;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Scanner;
import java.util.Set;

public class Client extends UnicastRemoteObject implements ClientRemote
{
	private final String nickname;

	Client(String nickname) throws RemoteException
	{
		super();
		assert nickname != null && nickname.matches("([a-zA-Z])+");
		this.nickname = nickname;
	}

	@Override
	public void receivedBroadcastedMessage(String sender, String msg) throws RemoteException
	{
		System.out.println(sender + "> " + msg);
	}

	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException
	{
		String serverHostname = "localhost";
		String nickname = args[0];

		ServerRemote server = (ServerRemote) Naming.lookup("rmi://" + serverHostname + "/ChatServer");

		Client client = new Client(nickname);
		server.registerClient(nickname, client);

		Scanner in = new Scanner(System.in);

		while (true)
		{
			String line = in.nextLine().trim();

			if (line.startsWith("/"))
			{
				// separate arguments, ignoring all spaces between them
				String[] lineElements = line.substring(1).split(" +");

				if (lineElements[0].equals("who"))
				{
					Set<String> clientNicknames = server.getClientNicknames();
					System.out.println(clientNicknames);
				}
			}
			else
			{
				server.broadcastMessage(nickname, line);
			}
		}
	}
}