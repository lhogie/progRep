package yac;

/*
 * http://tmthudugala.blogspot.fr/2008/01/java-rmi-chat-progarm-example.html
 * modified
 */

import java.rmi.*;
import java.util.Set;

public interface ServerRemote extends Remote
{
	void registerClient(String nickname, ClientRemote c) throws RemoteException;

	void broadcastMessage(String sender, String msg) throws RemoteException;

	Set<String> getClientNicknames() throws RemoteException;
}