package yac.correction;

import java.io.File;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server extends UnicastRemoteObject implements ServerRemote
{

	public static void main(String[] args) throws RemoteException, MalformedURLException
	{
		Naming.rebind("ChatServer", new Server());
	}

	private final Map<String, ClientRemote> nickname_clients = new HashMap<>();
	private final Map<String, FileConnectionInfo> nickname_ip = new HashMap<>();
	private final Map<String, Set<File>> nickname_sharedFiles = new HashMap<>();

	public Server() throws RemoteException
	{
		System.out.println("Server started");
	}

	@Override
	public Set<String> getClientNicknames()
	{
		return new HashSet<>(nickname_clients.keySet());
	}

	@Override
	public synchronized void registerClient(String nickname, ClientRemote c, FileConnectionInfo i)
			throws RemoteException
	{
		System.out.println("accepting new client " + nickname + " (" + i.ip.getHostName() + ", serving files on port " + i.port + ")");
		
		if (nickname_clients.containsKey(nickname))
			throw new IllegalArgumentException("nickname already registered: " + nickname);
		
		nickname_clients.put(nickname, c);
		nickname_ip.put(nickname, i);
		nickname_sharedFiles.put(nickname, new HashSet<File>());
		
		broadcastMessage(null, nickname + " joining");
	}

	@Override
	public synchronized void broadcastMessage(String sender, String msg)
			throws RemoteException
	{
		ExecutorService e = Executors.newFixedThreadPool(10);

		for (String n : nickname_clients.keySet())
		{
			// if the client is not the one that sent the message
			if (sender == null || ! n.equals(sender))
			{
				e.submit(new Runnable()
				{

					@Override
					public void run()
					{
						try
						{
							// relay the message
							nickname_clients.get(n).receivedMessage(sender,
									msg, true);
						}
						catch (RemoteException e)
						{
							e.printStackTrace();
						}
					}
				});

			}
		}
	}

	@Override
	public void kill(String user, String requester) throws RemoteException
	{
		nickname_clients.remove(user).kill(requester);
		
		broadcastMessage(null, user + " has been killed");
	}

	@Override
	public synchronized void nickname(String oldNickname, String newNickname) throws RemoteException
	{
		nickname_clients.put(newNickname, nickname_clients.remove(oldNickname));
		nickname_ip.put(newNickname, nickname_ip.remove(oldNickname));
		nickname_sharedFiles.put(newNickname, nickname_sharedFiles.remove(oldNickname));
		broadcastMessage(null, oldNickname + " is now known as " + newNickname);
	}

	@Override
	public void msg(String sender, String recipient, String msg) throws RemoteException
	{
		nickname_clients.get(recipient).receivedMessage(sender, msg, false);
	}

	@Override
	public void unshare(String nickname, Set<File> nolongSharedFiles) throws RemoteException
	{
		Set<File> sharedFiles = nickname_sharedFiles.get(nickname);
		sharedFiles.removeAll(nolongSharedFiles);
	}

	@Override
	public void share(String nickname, Set<File> newFiles) throws RemoteException
	{
		Set<File> sharedFiles = nickname_sharedFiles.get(nickname);
		sharedFiles.addAll(newFiles);
	}

	@Override
	public Set<File> getSharedFiles(String user) throws RemoteException
	{
		return nickname_sharedFiles.get(user);
	}

	@Override
	public Map<String, Set<File>> getSharedFiles() throws RemoteException
	{
		return nickname_sharedFiles;
	}

	@Override
	public Set<String> where(String filename) throws RemoteException
	{
		Set<String> r = new HashSet<>();
		
		for (Entry<String, Set<File>> e : nickname_sharedFiles.entrySet())
		{
			for (File f : e.getValue())
			{
				if (f.getName().matches(filename))
				{
					r.add(e.getKey());
				}
			}
		}
		
		return r;
	}

	@Override
	public FileConnectionInfo getInetAddress(String nickname)
	{
		return nickname_ip.get(nickname);
	}
}
