package yac.correction;

import java.rmi.*;

public interface ClientRemote extends Remote
{
	void receivedMessage(String sender, String msg, boolean bcast) throws RemoteException;


	void kill(String requester) throws RemoteException;
}