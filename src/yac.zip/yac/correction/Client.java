package yac.correction;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Client extends UnicastRemoteObject implements ClientRemote
{
	private static final int PORT_BASE = 50000;
	private String nickname;
	private final File directory;
	private Set<File> sharedFiles = new HashSet<>();
	private final ServerRemote server;
	private final FileConnectionInfo info;

	Client(ServerRemote server, String nickname) throws RemoteException, UnknownHostException
	{
		super();
		assert nickname != null && nickname.matches("([a-zA-Z])+");
		this.nickname = nickname;
		this.server = server;
		this.info = new FileConnectionInfo();
		this.info.ip = InetAddress.getLocalHost();
		this.info.port = PORT_BASE + new Random().nextInt(10000);
		System.out.println(this.info.port);
		this.directory = new File(
				System.getProperty("user.dir") + "/.yacc/" + nickname + "/shared_files");

		if ( ! directory.exists())
		{
			directory.mkdirs();
		}

		startFileTransferServer();
		watchDirectory();
	}

	private void watchDirectory()
	{
		new Thread(new Runnable()
		{

			@Override
			public void run()
			{
				while (true)
				{
					try
					{
						Thread.sleep(1000);
					}
					catch (InterruptedException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					Set<File> currentFiles = new HashSet<File>(
							Arrays.asList(directory.listFiles()));

					Set<File> nolongSharedFiles = new HashSet<>(sharedFiles);
					nolongSharedFiles.removeAll(currentFiles);

					try
					{
						server.unshare(nickname, nolongSharedFiles);
					}
					catch (RemoteException e1)
					{
						e1.printStackTrace();
					}

					Set<File> newFiles = new HashSet<>(currentFiles);
					newFiles.removeAll(sharedFiles);
					try
					{
						server.share(nickname, newFiles);
					}
					catch (RemoteException e1)
					{
						e1.printStackTrace();
					}

					sharedFiles = currentFiles;
				}
			}
		}).start();
	}

	private void startFileTransferServer()
	{
		new Thread(new Runnable()
		{

			@Override
			public void run()
			{
				try
				{
					ServerSocket serverSocket = new ServerSocket(info.port);

					while (true)
					{
						Socket client = serverSocket.accept();
						System.out.println("new file client");
						ObjectInputStream ois = new ObjectInputStream(
								client.getInputStream());
						String filename = (String) ois.readObject();
						System.out.println("it wants " + filename);
						File file = new File(directory, filename);
						ObjectOutputStream oos = new ObjectOutputStream(
								client.getOutputStream());
						oos.writeObject(Files.readAllBytes(file.toPath()));
						oos.flush();
						oos.close();
						client.close();
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}).start();

	}

	public static void main(String[] args) throws MalformedURLException, RemoteException,
			NotBoundException, UnknownHostException
	{
		String serverHostname = args[0];
		String nickname = args[1];

		ServerRemote server = (ServerRemote) Naming
				.lookup("rmi://" + serverHostname + "/ChatServer");

		Client client = new Client(server, nickname);
		
		server.registerClient(nickname, client, client.info);
		System.out.println("You are now connected to server " + serverHostname);
		System.out
				.println("Your shared file are in " + client.directory.getAbsolutePath());

		Scanner in = new Scanner(System.in);

		while (true)
		{
			String line = in.nextLine().trim();

			if (line.startsWith("/"))
			{
				// separate arguments, ignoring all spaces between them
				String[] lineElements = line.substring(1).split(" +");

				if (lineElements[0].equals("who"))
				{
					Set<String> clientNicknames = server.getClientNicknames();
					System.out.println(clientNicknames);
				}
				else if (lineElements[0].equals("kill"))
				{
					for (int i = 1; i < lineElements.length; ++i)
					{
						String user = lineElements[i];
						server.kill(user, nickname);
						System.out.println(user + " killed");
					}
				}
				else if (lineElements[0].equals("nick"))
				{
					String newNickname = lineElements[1];
					server.nickname(nickname, newNickname);
					client.setNickname(newNickname);
					System.out.println("you are now known as " + nickname);
				}
				else if (lineElements[0].equals("msg"))
				{
					String recipient = lineElements[1];
					String msg = "";

					for (int i = 2; i < lineElements.length; ++i)
					{
						msg += lineElements[i];
					}

					server.msg(nickname, recipient, msg);
					System.out.println(recipient + "> " + msg);
				}
				else if (lineElements[0].equals("own"))
				{
					String user = lineElements[1];

					for (File f : server.getSharedFiles(user))
					{
						System.out.println("- " + f.getName());
					}
				}
				else if (lineElements[0].equals("ls"))
				{
					Map<String, Set<File>> fileMap = server.getSharedFiles();
					Set<File> files = new HashSet<>();

					for (Set<File> u : fileMap.values())
					{
						files.addAll(u);
					}

					for (File f : files)
					{
						System.out.println("- " + f.getName());
					}
				}
				else if (lineElements[0].equals("where"))
				{
					String filename = lineElements[1];
					Set<String> where = server.where(filename);

					for (String u : where)
					{
						System.out.println(u);
					}
				}
				else if (lineElements[0].equals("sget"))
				{
					String filename = lineElements[1];
					Set<String> where = server.where(filename);
					long a = System.currentTimeMillis();
					FileConnectionInfo info = server.getInetAddress(where.iterator().next());

					try
					{
						Socket s = new Socket(info.ip, info.port);
						ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
						ObjectOutputStream oos = new ObjectOutputStream(
								s.getOutputStream());
						oos.writeObject(filename);
						oos.flush();
						byte[] fileContent = (byte[]) ois.readObject();
						File f = new File(client.directory, filename);
						FileOutputStream fos = new FileOutputStream(f);
						fos.write(fileContent);
						fos.close();
						s.close();
					}
					catch (IOException | ClassNotFoundException e)
					{
						e.printStackTrace();
					}

					System.out.println(
							"Downloaded in " + (System.currentTimeMillis() - a) + "ms");
				}
			}
			else
			{
				server.broadcastMessage(nickname, line);
			}
		}
	}

	public void setNickname(String newNickname)
	{
		if (newNickname == null)
			throw new NullPointerException();

		this.nickname = newNickname;
	}

	@Override
	public void receivedMessage(String sender, String msg, boolean bcast)
	{
		if (sender == null)
		{
			System.out.println("* " + msg);
		}
		else
		{
			System.out.println(sender + (bcast ? '>' : '#') + " " + msg);
		}
	}

	@Override
	public void kill(String requester)
	{
		System.out.println("You have been killed by " + requester);
		System.exit(1);
	}
}