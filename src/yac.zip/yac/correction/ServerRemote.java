package yac.correction;

import java.io.File;
import java.net.InetAddress;
/*
 * http://tmthudugala.blogspot.fr/2008/01/java-rmi-chat-progarm-example.html
 * modified
 */
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.Set;

public interface ServerRemote extends Remote
{
	void registerClient(String nickname, ClientRemote c, FileConnectionInfo i) throws RemoteException;

	void broadcastMessage(String sender, String msg) throws RemoteException;

	Set<String> getClientNicknames() throws RemoteException;

	void kill(String user, String requester) throws RemoteException;

	void nickname(String oldNickname, String newNickname) throws RemoteException;

	void msg(String sender, String recipient, String msg) throws RemoteException;

	void unshare(String nickname, Set<File> nolongSharedFiles)throws RemoteException;

	void share(String nickname, Set<File> newFiles)throws RemoteException;

	Set<File> getSharedFiles(String user) throws RemoteException;
	Map<String, Set<File>> getSharedFiles() throws RemoteException;

	Set<String> where(String filename) throws RemoteException;

	FileConnectionInfo getInetAddress(String next) throws RemoteException;
}