package yac.correction;

import java.io.Serializable;
import java.net.InetAddress;

public class FileConnectionInfo implements Serializable
{
	InetAddress ip;
	int port;
}
