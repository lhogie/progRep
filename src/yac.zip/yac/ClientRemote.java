package yac;

import java.rmi.*;

public interface ClientRemote extends Remote
{
	void receivedBroadcastedMessage(String sender, String msg) throws RemoteException;
}